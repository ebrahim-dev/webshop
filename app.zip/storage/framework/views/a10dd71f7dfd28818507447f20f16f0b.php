<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Responsive Bootstrap4 Shop Template, Created by Imran Hossain from https://imransdesign.com/">

	<!-- title -->
	<title>Sermedia - Slider Version</title>


	<!-- favicon -->
	<link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/img/favicon.png')); ?>">
	<!-- google font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet">
	<!-- fontawesome -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/all.min.css')); ?>">
	<!-- bootstrap -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/bootstrap/css/bootstrap.min.css')); ?>">
	<!-- owl carousel -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.css')); ?>">
	<!-- magnific popup -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/magnific-popup.css')); ?>">
	<!-- animate css -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>">
	<!-- mean menu css -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/meanmenu.min.css')); ?>">
	<!-- main style -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">
	<!-- responsive -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">

</head>
<body>

	<!--PreLoader-->
    <div class="loader">
        <div class="loader-inner">
            <div class="circle"></div>
        </div>
    </div>
    <!--PreLoader Ends-->

	<!-- header -->
	<div class="top-header-area" id="sticker">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-sm-12 text-center">
					<div class="main-menu-wrap">
						<!-- logo -->
						<div class="site-logo">
							<a href="/">
								<img src="<?php echo e(asset('assets\img\logo\20240326_131303_0000.png')); ?> " alt="" width="50%">
							</a>
						</div>
						<!-- logo -->

						<!-- menu start -->
						<nav class="main-menu">
							<ul>
								<li class="current-list-item"><a href="/"><?php echo e(__('string.home')); ?></a>
								</li>
								<li><a href="<?php echo e(route('products')); ?>">Product</a></li>
                                <li><a href="<?php echo e(route('categories')); ?>">Category</a></li>
                                <?php if(Auth::user()&&(Auth::user()->role=='admin' || Auth::user()->role=='saler')): ?>
                                <li><a href="<?php echo e(route('addproduct')); ?>"><?php echo e(__('string.addProduct')); ?></a></li>
                                <?php endif; ?>
                                <li><a href="<?php echo e(route('reviews')); ?>"><?php echo e(__('string.reviews')); ?></a></li>
                                <?php if(Auth::user()&&Auth::user()->role=='admin'): ?>
                                 <li><a href="<?php echo e(route('productstable')); ?>">Product table</a></li>
                                <?php endif; ?>



                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li >
                                    <a  href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li >
                                    <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li >
                                <a href="#">
                                    <?php echo e(Auth::user()->name); ?>

                                </a>
                            </li>
                            <li>
                                    <a  href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                            </li>
                        <?php endif; ?>

								<li>
									<div class="header-icons">
										<a class="shopping-cart" href="<?php echo e(route('cart')); ?>"><i class="fas fa-shopping-cart"></i></a>
										<a class="mobile-hide search-bar-icon" href="#"><i class="fas fa-search"></i></a>
									</div>
								</li>
							</ul>
						</nav>
						<a class="mobile-show search-bar-icon" href="#"><i class="fas fa-search"></i></a>
						<div class="mobile-menu"></div>
						<!-- menu end -->
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end header -->

	<!-- search area -->
	<div class="search-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<span class="close-btn"><i class="fas fa-window-close"></i></span>
					<div class="search-bar">
						<div class="search-bar-tablecell">
							<h3>Search For:</h3>
                            <form action="<?php echo e(route('search')); ?>" method="post">
                                <?php echo csrf_field(); ?>
							<input type="text" placeholder="Keywords" name="searchkey">
							<button type="submit">Search <i class="fas fa-search"></i></button>
                            </form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end search area -->

	<!-- home page slider -->
	<div class="homepage-slider">
		<!-- single home slider -->
		<div class="single-homepage-slider homepage-bg-1">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-lg-7 offset-lg-1 offset-xl-0">
						<div class="hero-text">
							<div class="hero-text-tablecell">
								<p class="subtitle">Delecious food</p>
								<h1>For all times</h1>
								<div class="hero-btns">
									<a href="<?php echo e(route('products')); ?>" class="boxed-btn">Visit Products</a>
									<a href="<?php echo e(route('categories')); ?>" class="bordered-btn">Discover the categories</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- single home slider -->
		<div class="single-homepage-slider homepage-bg-2">
			<div class="container">
				<div class="row">
					<div class="col-lg-10 offset-lg-1 text-center">
						<div class="hero-text">
							<div class="hero-text-tablecell">
								<p class="subtitle">Make your life easier</p>
								<h1>New technology</h1>
								<div class="hero-btns">
									<a href="<?php echo e(route('products')); ?>" class="boxed-btn">Visit Products</a>
									<a href="<?php echo e(route('categories')); ?>" class="bordered-btn">Discover the categories</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- single home slider -->
		<div class="single-homepage-slider homepage-bg-3">
			<div class="container">
				<div class="row">
					<div class="col-lg-10 offset-lg-1 text-right">
						<div class="hero-text">
							<div class="hero-text-tablecell">
								<p class="subtitle">Fast communication!</p>
								<h1>The newste catgets</h1>
								<div class="hero-btns">
									<a href="<?php echo e(route('products')); ?>" class="boxed-btn">Visit Products</a>
									<a href="<?php echo e(route('categories')); ?>" class="bordered-btn">Discover the categories</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end home page slider -->
<?php echo e(trans('string.welcome')); ?>


<form action="<?php echo e(route('changeLanguage','en')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <button type="submit"> English </button>
</form>
<form action="<?php echo e(route('changeLanguage','nl')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <button type="submit"> Nederland </button>
</form>
<?php echo $__env->yieldContent('content'); ?>

    	<!-- footer -->
	<div class="footer-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6">
					<div class="footer-box about-widget">
						<h2 class="widget-title">About us</h2>
						<p>Ut enim ad minim veniam perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae.</p>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="footer-box get-in-touch">
						<h2 class="widget-title">Get in Touch</h2>
						<ul>
							<li>34/8, East Hukupara, Gifirtok, Sadan.</li>
							<li>support@fruitkha.com</li>
							<li>+00 111 222 3333</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="footer-box pages">
						<h2 class="widget-title">Pages</h2>
						<ul>
							<li><a href="index.html">Home</a></li>
							<li><a href="about.html">About</a></li>
							<li><a href="services.html">Shop</a></li>
							<li><a href="news.html">News</a></li>
							<li><a href="contact.html">Contact</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="footer-box subscribe">
						<h2 class="widget-title">Subscribe</h2>
						<p>Subscribe to our mailing list to get the latest updates.</p>
						<form action="index.html">
							<input type="email" placeholder="Email">
							<button type="submit"><i class="fas fa-paper-plane"></i></button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end footer -->

	<!-- copyright -->
	<div class="copyright">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-12">
					<p>Copyrights &copy; 2019 - <a href="https://imransdesign.com/">Imran Hossain</a>,  All Rights Reserved.<br>
						Distributed By - <a href="https://themewagon.com/">Themewagon</a>
					</p>
				</div>
				<div class="col-lg-6 text-right col-md-12">
					<div class="social-icons">
						<ul>
							<li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
							<li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
							<li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
							<li><a href="#" target="_blank"><i class="fab fa-linkedin"></i></a></li>
							<li><a href="#" target="_blank"><i class="fab fa-dribbble"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end copyright -->

	<!-- jquery -->
	<script src="<?php echo e(asset('assets/js/jquery-1.11.3.min.js')); ?>"></script>
	<!-- bootstrap -->
	<script src="<?php echo e(asset('assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
	<!-- count down -->
	<script src="<?php echo e(asset('assets/js/jquery.countdown.js')); ?>"></script>
	<!-- isotope -->
	<script src="<?php echo e(asset('assets/js/jquery.isotope-3.0.6.min.js')); ?>"></script>
	<!-- waypoints -->
	<script src="<?php echo e(asset('assets/js/waypoints.js')); ?>"></script>
	<!-- owl carousel -->
	<script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
	<!-- magnific popup -->
	<script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
	<!-- mean menu -->
	<script src="<?php echo e(asset('assets/js/jquery.meanmenu.min.js')); ?>"></script>
	<!-- sticker js -->
	<script src="<?php echo e(asset('assets/js/sticker.js')); ?>"></script>
	<!-- main js -->
	<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\MAMP\htdocs\laravel_blog\resources\views/layouts/master.blade.php ENDPATH**/ ?>