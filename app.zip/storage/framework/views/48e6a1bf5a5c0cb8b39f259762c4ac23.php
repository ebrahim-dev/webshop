<?php $__env->startSection('content'); ?>
<div class="container" style="text-align: center">

        	<form method="POST" enctype="multipart/form-data" action="<?php echo e(url('/storeproductimage')); ?>" id="fruitkha-contact" onsubmit="return valid_datas( this );">
				<?php echo csrf_field(); ?>
                <div class="row  mt-5 mb-5">
                    <input type="hidden" name="product_id" id="product_id" required style="width: 100%" value="<?php echo e($product->id); ?>">
                    <div class="col-9 pt-3">
                        <input type="file"  name="photo" id="photo" class="form-control">
                        <span class="text-danger">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <?php echo e($message); ?>

                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </span>

                    </div>
                    <div class="col-3 ">
                        <input type="submit" value="Save" class="w-100">
                    </div>

                    <span class="text-danger">
                        <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
                </div>
			</form>

    <div class="row">
        <?php $__currentLoopData = $productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-3">
                <img src="<?php echo e(asset($item->imagepath)); ?>" width="300" height="300" alt="" class="m-2" >
                <a href="/removeproductphoto/<?php echo e($item->id); ?>" class="btn btn-danger "><i class="fas fa-trash"></i>Delete</a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\laravel_blog\resources\views/Products/addproductimages.blade.php ENDPATH**/ ?>