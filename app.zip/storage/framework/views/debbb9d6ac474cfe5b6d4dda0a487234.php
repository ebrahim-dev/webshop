<?php $__env->startSection('content'); ?>


			<div class="row product-lists">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-4 col-md-6 text-center strawberry">
					<div class="single-product-item" >
						<div class="product-image" >
							<a href="/single-product/<?php echo e($item->id); ?>"><img src="<?php echo e(url($item->imagepath)); ?>" alt="" style="height: 250px"></a>
						</div>
						<h3><?php echo e(session('local')=='en'? $item->name : $item->nameNL); ?></h3>
                        <h6 class="product-price"><?php echo e($item->description); ?> </h6>
						<p class="product-price"><?php echo e($item->price); ?>$ </p>
						<a href="/addproducttocart/<?php echo e($item->id); ?>" class="cart-btn">
                        ><i class="fas fa-shopping-cart"></i> Add to Cart</a>
                         <?php if(Auth::user()&&(Auth::user()->role=='admin' || Auth::user()->role=='saler')): ?>
                        <a href="/removeproducts/<?php echo e($item->id); ?>" class="btn btn-danger "><i class="fas fa-trash"></i>Delete</a>
                        <a href="/editproduct/<?php echo e($item->id); ?>" class="btn btn-primary "><i class="fas fa-pen"></i>Edit</a>
                        <?php endif; ?>
					</div>
				</div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div style="align-items: center; justify-content: center; width:100%; display: flex; text-align:center;">
                    <?php echo e($products->links()); ?>

                </div>

			</div>

<?php $__env->stopSection(); ?>
 <style>
    svg{
        height: 50px;
    }
 </style>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\laravel_blog\resources\views/product.blade.php ENDPATH**/ ?>