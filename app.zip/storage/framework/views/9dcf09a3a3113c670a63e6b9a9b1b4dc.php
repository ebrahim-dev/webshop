<?php $__env->startSection('content'); ?>



<!-- <div id="currentDate"></div>
<div id="currentTime"></div> -->
<!-- <?php echo e(Session('date')? 'ahmad':'mohamed'); ?> -->
<?php echo e(Session('username')); ?>

<div class="row product-lists">

    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-4 col-md-6 text-center strawberry">
        <div class="single-product-item" style="height: 600px">
            <div class="product-image">
                <a href="/products/<?php echo e($item->id); ?>"><img src="<?php echo e(url($item->imagepath)); ?>" alt=""
                        style="height: 300px !important; margin:20px "></a>
            </div>
            <h3><?php echo e($item->name); ?></h3>
            <p><?php echo e($item->description); ?></p>

        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<!-- <script>
// Functie om de huidige datum en tijd op te halen en weer te geven
function updateDateTime() {
    var currentDateElement = document.getElementById('currentDate');
    var currentTimeElement = document.getElementById('currentTime');
    var currentDateTime = new Date();
    var date = currentDateTime.toLocaleDateString();
    var time = currentDateTime.toLocaleTimeString();
    currentDateElement.innerHTML = date;
    currentTimeElement.innerHTML = time;
}

// Roept de functie updateDateTime aan om de huidige datum en tijd in te stellen
updateDateTime();

// Update de tijd elke seconde
setInterval(updateDateTime, 1000);
</script> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\laravel_blog\resources\views/welcome.blade.php ENDPATH**/ ?>