<?php $__env->startSection('content'); ?>
<div class="section-title text-center mt-4">
    <h3><span class="orange-text">Product</span> details</h3>
</div>
	<!-- single product -->
	<div class="single-product mt-150 mb-150">
		<div class="container">
			<div class="row">
				<div class="col-md-5">
					<div class="single-product-img">
						<img src="<?php echo e(asset($product->imagepath)); ?>" alt="">
					</div>
				</div>
				<div class="col-md-7">
					<div class="single-product-content">
						<h3><?php echo e($product->name); ?></h3>
						<p class="single-product-pricing"> $<?php echo e($product->price); ?></p>
						<p><?php echo e($product->description); ?></p>
                        <p>Quantity: <?php echo e($product->quantity); ?> </p>
						<div class="single-product-form">
							<a href="/addproducttocart/<?php echo e($product->id); ?>" class="cart-btn"><i class="fas fa-shopping-cart"></i> Add to Cart</a>
							<p><strong>Categories: </strong><?php echo e($product->Category->name); ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end single product -->
    <?php if($product->ProductPhoto->count() > 1): ?>


<div class="testimonail-section mt-80 mb-150">
		<div class="container">
			<div class="row">
				<div class="col-lg-10 offset-lg-1 text-center">
					<div class="testimonial-sliders">
                        <?php $__currentLoopData = $product->ProductPhoto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          	<div class="single-testimonial-slider">
                                <div class="client-avater">
                                    <img style="max-width: none !important; width:30%; height:300px;" src="<?php echo e(asset($item -> imagepath)); ?>" alt="">
                                </div>
						    </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>

</div>

<?php endif; ?>
        <div class="container">
            	<div class="section-title text-center mt-4">
                    <h3><span class="orange-text">Related</span> products</h3>
				</div>
            <div class="row product-lists">
                <?php $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-lg-4 col-md-6 text-center " style="display: flex;">
					<div class="single-product-item" >
						<div class="product-image" >
							<a href="/single-product/<?php echo e($item->id); ?>"><img src="<?php echo e(url($item->imagepath)); ?>" alt="" style="height: 250px"></a>
						</div>
						<h3><?php echo e($item->name); ?></h3>
                        <h6 class="product-price"><?php echo e($item->description); ?> </h6>
						<p class="product-price"><?php echo e($item->price); ?>$ </p>
						<a href="/addproducttocart/<?php echo e($item->id); ?>" class="cart-btn">
                        ><i class="fas fa-shopping-cart"></i> Add to Cart</a>
					</div>
				</div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>
        </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\laravel_blog\resources\views/Products/showProduct.blade.php ENDPATH**/ ?>