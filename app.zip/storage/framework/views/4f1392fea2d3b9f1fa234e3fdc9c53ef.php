<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-compat/3.0.0-alpha1/jquery.min.js" integrity="sha512-4GsgvzFFry8SXj8c/VcCjjEZ+du9RZp/627AEQRVLatx6d60AUnUYXg0lGn538p44cgRs5E2GXq+8IOetJ+6ow==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/2.0.2/css/dataTables.dataTables.min.css">
<script src="https://cdn.datatables.net/2.0.2/js/dataTables.min.js"></script>

<?php $__env->startSection('content'); ?>
<div class="container mt-5 mb-5">
    <a href="/addproduct" class="btn btn-success "><i class="fas fa-plus"></i>Add product</a>
<table id="myTable" class="display" style="text-align: center">
    <thead>
        <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Created at</th>
            <th>Image</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->id); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->price); ?></td>
                <td><?php echo e($item->quantity); ?></td>
                <td><?php echo e($item->created_at); ?></td>
                <td><img src="<?php echo e($item->imagepath); ?>" alt="" height="75" width="75"></td>
                <td> <a href="/removeproducts/<?php echo e($item->id); ?>" class="btn btn-danger "><i class="fas fa-trash"></i>Delete</a>
                    <a href="/editproduct/<?php echo e($item->id); ?>" class="btn btn-primary "><i class="fas fa-pen"></i>Edit</a>
                    <a href="/addproductimages/<?php echo e($item->id); ?>" class="btn btn-dark "><i class="fas fa-image"></i>Add images</a>
                </td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>

<script>
    $(document).ready( function () {
    let table = new DataTable('#myTable');
} );
</script>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAMP\htdocs\laravel_blog\resources\views/Products/productstable.blade.php ENDPATH**/ ?>