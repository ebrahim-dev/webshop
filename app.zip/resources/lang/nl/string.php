<?php

return [
    'welcome'=>'Welkom in onze website',
    'home'=>'Huis',
    'addProduct'=>'Voeg een product toe',
    'reviews'=>'Opmerkingen',
];
