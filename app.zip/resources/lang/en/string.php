<?php

return [
    'welcome'=>'Welcome to our website',
    'home'=>'Home',
    'addProduct'=>'Add product',
    'reviews'=>'Reviews',
    // 'home'=>'Home',

];
